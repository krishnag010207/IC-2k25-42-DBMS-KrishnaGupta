-- DBMS Assignment 2
-- Question 19: 19. Get monthly salary rounded to 2 decimal places

SELECT employee_id,
       first_name,
       last_name,
       ROUND(salary / 12, 2) AS monthly_salary
FROM employees;
