-- DBMS Assignment 2
-- Question 9: 9. Get number of employees working in the company

SELECT COUNT(*) AS employee_count
FROM employees;
