-- DBMS Assignment 2
-- Question 13: 13. Calculate `171*214+625`

SELECT 171 * 214 + 625 AS result;
