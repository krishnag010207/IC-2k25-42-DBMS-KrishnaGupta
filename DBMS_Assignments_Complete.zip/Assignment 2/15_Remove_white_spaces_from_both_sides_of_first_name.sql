-- DBMS Assignment 2
-- Question 15: 15. Remove white spaces from both sides of first name

SELECT TRIM(first_name) AS first_name
FROM employees;
