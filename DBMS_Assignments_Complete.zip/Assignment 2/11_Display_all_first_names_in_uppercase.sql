-- DBMS Assignment 2
-- Question 11: 11. Display all first names in uppercase

SELECT UPPER(first_name) AS first_name
FROM employees;
