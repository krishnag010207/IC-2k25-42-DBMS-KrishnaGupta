-- DBMS Assignment 2
-- Question 8: 8. Get average salary and number of employees

SELECT AVG(salary) AS average_salary,
       COUNT(*) AS number_of_employees
FROM employees;
