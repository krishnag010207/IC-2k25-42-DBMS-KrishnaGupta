-- DBMS Assignment 2
-- Question 18: 18. Select the first 10 records

SELECT *
FROM employees
LIMIT 10;
