# DBMS Assignment 2

This folder contains the **19 individual SQL solutions** for DBMS Assignment 2.

## Questions

1. [1. Display names using aliases](01_Display_names_using_aliases.sql)
2. [2. Get unique department IDs](02_Get_unique_department_IDs.sql)
3. [3. Display all employees ordered by first name descending](03_Display_all_employees_ordered_by_first_name_descending.sql)
4. [4. Display name, salary, and PF (15% of salary)](04_Display_name_salary_and_PF_15_of_salary.sql)
5. [5. Display employee ID, name, and salary in ascending salary order](05_Display_employee_ID_name_and_salary_in_ascending_salary_order.sql)
6. [6. Get total salaries payable](06_Get_total_salaries_payable.sql)
7. [7. Get maximum and minimum salary](07_Get_maximum_and_minimum_salary.sql)
8. [8. Get average salary and number of employees](08_Get_average_salary_and_number_of_employees.sql)
9. [9. Get number of employees working in the company](09_Get_number_of_employees_working_in_the_company.sql)
10. [10. Get number of jobs available in the employees table](10_Get_number_of_jobs_available_in_the_employees_table.sql)
11. [11. Display all first names in uppercase](11_Display_all_first_names_in_uppercase.sql)
12. [12. Get the first 3 characters of first name](12_Get_the_first_3_characters_of_first_name.sql)
13. [13. Calculate `171*214+625`](13_Calculate_171_214_625.sql)
14. [14. Display employee names such as `Ellen Abel`](14_Display_employee_names_such_as_Ellen_Abel.sql)
15. [15. Remove white spaces from both sides of first name](15_Remove_white_spaces_from_both_sides_of_first_name.sql)
16. [16. Get the length of employee names](16_Get_the_length_of_employee_names.sql)
17. [17. Check whether first names contain numbers](17_Check_whether_first_names_contain_numbers.sql)
18. [18. Select the first 10 records](18_Select_the_first_10_records.sql)
19. [19. Get monthly salary rounded to 2 decimal places](19_Get_monthly_salary_rounded_to_2_decimal_places.sql)

## Database

MySQL / HR-style database schema as required by the assignment.

## Submission Structure

Each question is stored as a separate `.sql` file so that it can be uploaded and executed independently.
