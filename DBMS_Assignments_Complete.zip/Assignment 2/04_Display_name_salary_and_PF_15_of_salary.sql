-- DBMS Assignment 2
-- Question 4: 4. Display name, salary, and PF (15% of salary)

SELECT CONCAT(first_name, ' ', last_name) AS name,
       salary,
       salary * 0.15 AS PF
FROM employees;
