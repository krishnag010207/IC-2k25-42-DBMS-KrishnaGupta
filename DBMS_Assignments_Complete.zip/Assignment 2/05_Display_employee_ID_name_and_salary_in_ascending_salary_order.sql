-- DBMS Assignment 2
-- Question 5: 5. Display employee ID, name, and salary in ascending salary order

SELECT employee_id,
       CONCAT(first_name, ' ', last_name) AS name,
       salary
FROM employees
ORDER BY salary ASC;
