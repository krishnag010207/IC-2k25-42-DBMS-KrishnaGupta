-- DBMS Assignment 2
-- Question 16: 16. Get the length of employee names

SELECT CONCAT(first_name, ' ', last_name) AS employee_name,
       LENGTH(CONCAT(first_name, ' ', last_name)) AS name_length
FROM employees;
