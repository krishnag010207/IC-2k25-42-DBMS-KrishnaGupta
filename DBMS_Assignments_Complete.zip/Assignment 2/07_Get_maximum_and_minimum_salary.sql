-- DBMS Assignment 2
-- Question 7: 7. Get maximum and minimum salary

SELECT MAX(salary) AS maximum_salary,
       MIN(salary) AS minimum_salary
FROM employees;
