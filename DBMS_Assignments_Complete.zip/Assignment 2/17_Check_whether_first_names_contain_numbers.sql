-- DBMS Assignment 2
-- Question 17: 17. Check whether first names contain numbers

SELECT first_name
FROM employees
WHERE first_name REGEXP '[0-9]';
