-- DBMS Assignment 2
-- Question 1: 1. Display names using aliases

SELECT first_name AS `First Name`,
       last_name AS `Last Name`
FROM employees;
