-- DBMS Assignment 2
-- Question 10: 10. Get number of jobs available in the employees table

SELECT COUNT(DISTINCT job_id) AS number_of_jobs
FROM employees;
