-- DBMS Assignment 2
-- Question 2: 2. Get unique department IDs

SELECT DISTINCT department_id
FROM employees;
