-- DBMS Assignment 2
-- Question 3: 3. Display all employees ordered by first name descending

SELECT *
FROM employees
ORDER BY first_name DESC;
