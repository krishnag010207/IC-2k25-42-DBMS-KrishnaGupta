-- DBMS Assignment 2
-- Question 14: 14. Display employee names such as `Ellen Abel`

SELECT CONCAT(first_name, ' ', last_name) AS employee_name
FROM employees;
