-- DBMS Assignment 2
-- Question 12: 12. Get the first 3 characters of first name

SELECT SUBSTRING(first_name, 1, 3) AS first_three_characters
FROM employees;
