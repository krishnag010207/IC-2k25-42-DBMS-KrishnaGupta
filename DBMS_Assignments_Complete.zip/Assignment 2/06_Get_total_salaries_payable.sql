-- DBMS Assignment 2
-- Question 6: 6. Get total salaries payable

SELECT SUM(salary) AS total_salary
FROM employees;
