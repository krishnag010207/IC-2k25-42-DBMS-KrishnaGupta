-- DBMS Assignment 5
-- Question 11: 11. Employees earning more than all Shipping Clerks

SELECT first_name,
       last_name,
       salary
FROM employees
WHERE salary > ALL (
    SELECT salary
    FROM employees
    WHERE job_id = 'SH_CLERK'
)
ORDER BY salary ASC;
