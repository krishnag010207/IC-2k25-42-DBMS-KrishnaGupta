-- DBMS Assignment 5
-- Question 9: 9. Employees earning the same salary as the minimum salary for all departments

SELECT first_name,
       last_name,
       salary
FROM employees
WHERE salary = (
    SELECT MIN(salary)
    FROM employees
);
