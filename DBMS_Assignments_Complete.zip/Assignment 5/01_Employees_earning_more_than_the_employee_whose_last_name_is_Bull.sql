-- DBMS Assignment 5
-- Question 1: 1. Employees earning more than the employee whose last name is `Bull`

SELECT first_name,
       last_name,
       salary
FROM employees
WHERE salary > (
    SELECT salary
    FROM employees
    WHERE last_name = 'Bull'
);
