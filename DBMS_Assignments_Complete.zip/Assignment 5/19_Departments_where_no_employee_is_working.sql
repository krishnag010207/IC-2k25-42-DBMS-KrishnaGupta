-- DBMS Assignment 5
-- Question 19: 19. Departments where no employee is working

SELECT department_id,
       department_name
FROM departments
WHERE department_id NOT IN (
    SELECT DISTINCT department_id
    FROM employees
    WHERE department_id IS NOT NULL
);
