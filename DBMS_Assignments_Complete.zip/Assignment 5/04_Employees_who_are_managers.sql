-- DBMS Assignment 5
-- Question 4: 4. Employees who are managers

SELECT first_name,
       last_name
FROM employees
WHERE employee_id IN (
    SELECT manager_id
    FROM employees
    WHERE manager_id IS NOT NULL
);
