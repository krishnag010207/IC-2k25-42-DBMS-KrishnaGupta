-- DBMS Assignment 5
-- Question 21: 21. Get 3 minimum salaries

SELECT DISTINCT salary
FROM employees
ORDER BY salary ASC
LIMIT 3;
