-- DBMS Assignment 5
-- Question 5: 5. Employees whose salary is greater than the average salary

SELECT first_name,
       last_name,
       salary
FROM employees
WHERE salary > (
    SELECT AVG(salary)
    FROM employees
);
