-- DBMS Assignment 5
-- Question 17: 17. Find the 4th minimum salary

SELECT DISTINCT salary
FROM employees e1
WHERE 3 = (
    SELECT COUNT(DISTINCT salary)
    FROM employees e2
    WHERE e2.salary < e1.salary
);
