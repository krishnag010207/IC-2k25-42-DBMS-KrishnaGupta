-- DBMS Assignment 5
-- Question 10: 10. Employees whose salary is greater than the average salary of all departments

SELECT first_name,
       last_name,
       salary
FROM employees
WHERE salary > ALL (
    SELECT AVG(salary)
    FROM employees
    GROUP BY department_id
);
