-- DBMS Assignment 5
-- Question 2: 2. Employees who work in the IT department

SELECT first_name,
       last_name
FROM employees
WHERE department_id IN (
    SELECT department_id
    FROM departments
    WHERE department_name LIKE 'IT%'
);
