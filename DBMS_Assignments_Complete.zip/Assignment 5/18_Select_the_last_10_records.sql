-- DBMS Assignment 5
-- Question 18: 18. Select the last 10 records

SELECT *
FROM employees
ORDER BY employee_id DESC
LIMIT 10;
