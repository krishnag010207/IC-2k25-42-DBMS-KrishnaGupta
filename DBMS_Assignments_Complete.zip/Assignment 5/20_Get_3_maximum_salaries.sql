-- DBMS Assignment 5
-- Question 20: 20. Get 3 maximum salaries

SELECT DISTINCT salary
FROM employees
ORDER BY salary DESC
LIMIT 3;
