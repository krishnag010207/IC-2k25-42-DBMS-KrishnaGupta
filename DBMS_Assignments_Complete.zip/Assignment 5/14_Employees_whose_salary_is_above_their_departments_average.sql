-- DBMS Assignment 5
-- Question 14: 14. Employees whose salary is above their department's average

SELECT employee_id,
       first_name,
       last_name,
       salary
FROM employees e
WHERE salary > (
    SELECT AVG(salary)
    FROM employees
    WHERE department_id = e.department_id
);
