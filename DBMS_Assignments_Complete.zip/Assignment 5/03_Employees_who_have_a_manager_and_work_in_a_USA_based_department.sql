-- DBMS Assignment 5
-- Question 3: 3. Employees who have a manager and work in a USA-based department

SELECT first_name,
       last_name
FROM employees
WHERE manager_id IS NOT NULL
  AND department_id IN (
      SELECT department_id
      FROM departments
      WHERE location_id IN (
          SELECT location_id
          FROM locations
          WHERE country_id = 'US'
      )
  );
