-- DBMS Assignment 5
-- Question 16: 16. Find the 5th maximum salary

SELECT DISTINCT salary
FROM employees e1
WHERE 4 = (
    SELECT COUNT(DISTINCT salary)
    FROM employees e2
    WHERE e2.salary > e1.salary
);
