-- DBMS Assignment 5
-- Question 8: 8. Employees earning more than Mr. Bell

SELECT first_name,
       last_name,
       salary
FROM employees
WHERE salary > (
    SELECT salary
    FROM employees
    WHERE last_name = 'Bell'
);
