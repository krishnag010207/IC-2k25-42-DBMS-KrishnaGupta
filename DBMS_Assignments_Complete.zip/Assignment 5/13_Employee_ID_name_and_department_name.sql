-- DBMS Assignment 5
-- Question 13: 13. Employee ID, name, and department name

SELECT employee_id,
       first_name,
       last_name,
       department_name
FROM employees
JOIN departments
    ON employees.department_id = departments.department_id;
