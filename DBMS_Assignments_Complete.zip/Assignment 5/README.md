# DBMS Assignment 5

This folder contains the **22 individual SQL solutions** for DBMS Assignment 5.

## Questions

1. [1. Employees earning more than the employee whose last name is `Bull`](01_Employees_earning_more_than_the_employee_whose_last_name_is_Bull.sql)
2. [2. Employees who work in the IT department](02_Employees_who_work_in_the_IT_department.sql)
3. [3. Employees who have a manager and work in a USA-based department](03_Employees_who_have_a_manager_and_work_in_a_USA_based_department.sql)
4. [4. Employees who are managers](04_Employees_who_are_managers.sql)
5. [5. Employees whose salary is greater than the average salary](05_Employees_whose_salary_is_greater_than_the_average_salary.sql)
6. [6. Employees whose salary equals the minimum salary for their job](06_Employees_whose_salary_equals_the_minimum_salary_for_their_job.sql)
7. [7. Employees earning above average and working in an IT department](07_Employees_earning_above_average_and_working_in_an_IT_department.sql)
8. [8. Employees earning more than Mr. Bell](08_Employees_earning_more_than_Mr_Bell.sql)
9. [9. Employees earning the same salary as the minimum salary for all departments](09_Employees_earning_the_same_salary_as_the_minimum_salary_for_all_depart.sql)
10. [10. Employees whose salary is greater than the average salary of all departments](10_Employees_whose_salary_is_greater_than_the_average_salary_of_all_depar.sql)
11. [11. Employees earning more than all Shipping Clerks](11_Employees_earning_more_than_all_Shipping_Clerks.sql)
12. [12. Employees who are not supervisors](12_Employees_who_are_not_supervisors.sql)
13. [13. Employee ID, name, and department name](13_Employee_ID_name_and_department_name.sql)
14. [14. Employees whose salary is above their department's average](14_Employees_whose_salary_is_above_their_departments_average.sql)
15. [15. Fetch even-numbered records from employees](15_Fetch_even_numbered_records_from_employees.sql)
16. [16. Find the 5th maximum salary](16_Find_the_5th_maximum_salary.sql)
17. [17. Find the 4th minimum salary](17_Find_the_4th_minimum_salary.sql)
18. [18. Select the last 10 records](18_Select_the_last_10_records.sql)
19. [19. Departments where no employee is working](19_Departments_where_no_employee_is_working.sql)
20. [20. Get 3 maximum salaries](20_Get_3_maximum_salaries.sql)
21. [21. Get 3 minimum salaries](21_Get_3_minimum_salaries.sql)
22. [22. Find the Nth maximum salary](22_Find_the_Nth_maximum_salary.sql)

## Database

MySQL / HR-style database schema as required by the assignment.

## Submission Structure

Each question is stored as a separate `.sql` file so that it can be uploaded and executed independently.
