-- DBMS Assignment 5
-- Question 15: 15. Fetch even-numbered records from employees

SELECT *
FROM employees
WHERE MOD(employee_id, 2) = 0;
