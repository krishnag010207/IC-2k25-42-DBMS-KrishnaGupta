-- DBMS Assignment 5
-- Question 6: 6. Employees whose salary equals the minimum salary for their job

SELECT first_name,
       last_name,
       salary
FROM employees
WHERE salary = (
    SELECT min_salary
    FROM jobs
    WHERE jobs.job_id = employees.job_id
);
