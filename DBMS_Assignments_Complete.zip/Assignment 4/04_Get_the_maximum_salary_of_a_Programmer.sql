-- DBMS Assignment 4
-- Question 4: 4. Get the maximum salary of a Programmer

SELECT MAX(salary) AS maximum_programmer_salary
FROM employees
WHERE job_id = 'IT_PROG';
