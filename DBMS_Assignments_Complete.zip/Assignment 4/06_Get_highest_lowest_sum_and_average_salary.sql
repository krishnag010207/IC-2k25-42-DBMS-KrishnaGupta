-- DBMS Assignment 4
-- Question 6: 6. Get highest, lowest, sum, and average salary

SELECT MAX(salary) AS highest_salary,
       MIN(salary) AS lowest_salary,
       SUM(salary) AS total_salary,
       AVG(salary) AS average_salary
FROM employees;
