-- DBMS Assignment 4
-- Question 1: 1. List the number of jobs available

SELECT COUNT(DISTINCT job_id) AS number_of_jobs
FROM employees;
