-- DBMS Assignment 4
-- Question 8: 8. Difference between highest and lowest salaries

SELECT MAX(salary) - MIN(salary) AS salary_difference
FROM employees;
