-- DBMS Assignment 4
-- Question 2: 2. Get the total salaries payable

SELECT SUM(salary) AS total_salary
FROM employees;
