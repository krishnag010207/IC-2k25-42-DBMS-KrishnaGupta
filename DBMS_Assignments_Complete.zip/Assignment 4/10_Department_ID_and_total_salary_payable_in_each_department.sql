-- DBMS Assignment 4
-- Question 10: 10. Department ID and total salary payable in each department

SELECT department_id,
       SUM(salary) AS total_salary
FROM employees
GROUP BY department_id;
