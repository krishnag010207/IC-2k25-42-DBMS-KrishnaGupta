# DBMS Assignment 4

This folder contains the **14 individual SQL solutions** for DBMS Assignment 4.

## Questions

1. [1. List the number of jobs available](01_List_the_number_of_jobs_available.sql)
2. [2. Get the total salaries payable](02_Get_the_total_salaries_payable.sql)
3. [3. Get the minimum salary](03_Get_the_minimum_salary.sql)
4. [4. Get the maximum salary of a Programmer](04_Get_the_maximum_salary_of_a_Programmer.sql)
5. [5. Get average salary and number of employees in department 90](05_Get_average_salary_and_number_of_employees_in_department_90.sql)
6. [6. Get highest, lowest, sum, and average salary](06_Get_highest_lowest_sum_and_average_salary.sql)
7. [7. Get the number of employees with the same job](07_Get_the_number_of_employees_with_the_same_job.sql)
8. [8. Difference between highest and lowest salaries](08_Difference_between_highest_and_lowest_salaries.sql)
9. [9. Manager ID and salary of the lowest-paid employee for each manager](09_Manager_ID_and_salary_of_the_lowest_paid_employee_for_each_manager.sql)
10. [10. Department ID and total salary payable in each department](10_Department_ID_and_total_salary_payable_in_each_department.sql)
11. [11. Average salary for each job ID excluding Programmer](11_Average_salary_for_each_job_ID_excluding_Programmer.sql)
12. [12. Total, maximum, minimum, and average salary job-wise for department 90](12_Total_maximum_minimum_and_average_salary_job_wise_for_department_90.sql)
13. [13. Job ID and maximum salary where maximum salary is at least 4000](13_Job_ID_and_maximum_salary_where_maximum_salary_is_at_least_4000.sql)
14. [14. Average salary for departments employing more than 10 employees](14_Average_salary_for_departments_employing_more_than_10_employees.sql)

## Database

MySQL / HR-style database schema as required by the assignment.

## Submission Structure

Each question is stored as a separate `.sql` file so that it can be uploaded and executed independently.
