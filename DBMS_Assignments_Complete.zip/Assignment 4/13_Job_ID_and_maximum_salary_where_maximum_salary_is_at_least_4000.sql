-- DBMS Assignment 4
-- Question 13: 13. Job ID and maximum salary where maximum salary is at least 4000

SELECT job_id,
       MAX(salary) AS maximum_salary
FROM employees
GROUP BY job_id
HAVING MAX(salary) >= 4000;
