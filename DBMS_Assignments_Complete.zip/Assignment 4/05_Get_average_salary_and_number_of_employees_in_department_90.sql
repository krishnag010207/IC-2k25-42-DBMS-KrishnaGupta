-- DBMS Assignment 4
-- Question 5: 5. Get average salary and number of employees in department 90

SELECT AVG(salary) AS average_salary,
       COUNT(*) AS employee_count
FROM employees
WHERE department_id = 90;
