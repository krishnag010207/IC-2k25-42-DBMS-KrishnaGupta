-- DBMS Assignment 4
-- Question 7: 7. Get the number of employees with the same job

SELECT job_id,
       COUNT(*) AS employee_count
FROM employees
GROUP BY job_id;
