-- DBMS Assignment 4
-- Question 9: 9. Manager ID and salary of the lowest-paid employee for each manager

SELECT manager_id,
       MIN(salary) AS lowest_salary
FROM employees
WHERE manager_id IS NOT NULL
GROUP BY manager_id;
