-- DBMS Assignment 4
-- Question 14: 14. Average salary for departments employing more than 10 employees

SELECT department_id,
       AVG(salary) AS average_salary
FROM employees
GROUP BY department_id
HAVING COUNT(*) > 10;
