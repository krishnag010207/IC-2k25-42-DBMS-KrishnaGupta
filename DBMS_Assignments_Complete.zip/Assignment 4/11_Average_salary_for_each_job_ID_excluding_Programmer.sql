-- DBMS Assignment 4
-- Question 11: 11. Average salary for each job ID excluding Programmer

SELECT job_id,
       AVG(salary) AS average_salary
FROM employees
WHERE job_id <> 'IT_PROG'
GROUP BY job_id;
