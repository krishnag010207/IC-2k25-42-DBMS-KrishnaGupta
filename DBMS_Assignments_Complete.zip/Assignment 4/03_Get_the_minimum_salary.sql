-- DBMS Assignment 4
-- Question 3: 3. Get the minimum salary

SELECT MIN(salary) AS minimum_salary
FROM employees;
