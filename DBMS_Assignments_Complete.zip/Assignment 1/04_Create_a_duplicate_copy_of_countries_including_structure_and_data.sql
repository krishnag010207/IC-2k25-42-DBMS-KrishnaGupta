-- DBMS Assignment 1
-- Question 4: 4. Create a duplicate copy of `countries` including structure and data

CREATE TABLE dup_countries LIKE countries;

INSERT INTO dup_countries
SELECT *
FROM countries;
