-- DBMS Assignment 1
-- Question 14: 14. `job_history` with unique employee IDs and a foreign key to `jobs`

CREATE TABLE IF NOT EXISTS job_history (
    employee_id DECIMAL(6,0) NOT NULL UNIQUE,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    job_id VARCHAR(10) NOT NULL,
    department_id DECIMAL(4,0) NOT NULL,
    FOREIGN KEY (job_id)
        REFERENCES jobs(job_id)
);
