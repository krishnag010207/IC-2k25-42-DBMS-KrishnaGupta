-- DBMS Assignment 1
-- Question 9: 9. Do not allow duplicate `country_id`

CREATE TABLE IF NOT EXISTS countries (
    country_id VARCHAR(2) NOT NULL UNIQUE,
    country_name VARCHAR(40),
    region_id DECIMAL(10,0)
);
