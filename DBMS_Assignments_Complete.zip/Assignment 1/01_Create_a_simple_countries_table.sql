-- DBMS Assignment 1
-- Question 1: 1. Create a simple `countries` table

CREATE TABLE countries (
    country_id VARCHAR(2),
    country_name VARCHAR(40),
    region_id DECIMAL(10,0)
);
