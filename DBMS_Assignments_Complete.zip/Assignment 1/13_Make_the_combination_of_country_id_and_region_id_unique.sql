-- DBMS Assignment 1
-- Question 13: 13. Make the combination of `country_id` and `region_id` unique

CREATE TABLE IF NOT EXISTS countries (
    country_id VARCHAR(2),
    country_name VARCHAR(40),
    region_id DECIMAL(10,0),
    UNIQUE (country_id, region_id)
);
