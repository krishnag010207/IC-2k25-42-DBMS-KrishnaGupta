-- DBMS Assignment 1
-- Question 7: 7. Allow only Italy, India, and China

CREATE TABLE IF NOT EXISTS countries (
    country_id VARCHAR(2),
    country_name VARCHAR(40),
    region_id DECIMAL(10,0),
    CHECK (country_name IN ('Italy', 'India', 'China'))
);
