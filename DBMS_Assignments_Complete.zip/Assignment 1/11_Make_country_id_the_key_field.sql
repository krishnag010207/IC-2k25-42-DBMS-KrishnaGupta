-- DBMS Assignment 1
-- Question 11: 11. Make `country_id` the key field

CREATE TABLE IF NOT EXISTS countries (
    country_id VARCHAR(2) NOT NULL PRIMARY KEY,
    country_name VARCHAR(40),
    region_id DECIMAL(10,0)
);
