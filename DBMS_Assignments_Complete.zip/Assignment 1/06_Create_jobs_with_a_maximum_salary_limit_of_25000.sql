-- DBMS Assignment 1
-- Question 6: 6. Create `jobs` with a maximum salary limit of 25000

CREATE TABLE IF NOT EXISTS jobs (
    job_id VARCHAR(10) NOT NULL,
    job_title VARCHAR(35) NOT NULL,
    min_salary DECIMAL(6,0),
    max_salary DECIMAL(6,0),
    CHECK (max_salary <= 25000)
);
