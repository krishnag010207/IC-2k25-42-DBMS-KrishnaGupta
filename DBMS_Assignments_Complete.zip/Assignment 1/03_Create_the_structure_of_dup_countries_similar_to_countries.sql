-- DBMS Assignment 1
-- Question 3: 3. Create the structure of `dup_countries` similar to `countries`

CREATE TABLE IF NOT EXISTS dup_countries
LIKE countries;
