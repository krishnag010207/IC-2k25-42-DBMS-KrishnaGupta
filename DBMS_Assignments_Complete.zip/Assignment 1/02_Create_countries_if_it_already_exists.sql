-- DBMS Assignment 1
-- Question 2: 2. Create `countries` if it already exists

CREATE TABLE IF NOT EXISTS countries (
    country_id VARCHAR(2),
    country_name VARCHAR(40),
    region_id DECIMAL(10,0)
);
