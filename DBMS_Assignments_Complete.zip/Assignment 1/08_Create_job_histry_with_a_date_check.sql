-- DBMS Assignment 1
-- Question 8: 8. Create `job_histry` with a date check

CREATE TABLE IF NOT EXISTS job_histry (
    employee_id DECIMAL(6,0) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    job_id VARCHAR(10) NOT NULL,
    department_id DECIMAL(4,0) NOT NULL,
    CHECK (end_date IS NOT NULL)
);
