-- DBMS Assignment 1
-- Question 10: 10. Create `jobs` with default values

CREATE TABLE IF NOT EXISTS jobs (
    job_id VARCHAR(10) NOT NULL,
    job_title VARCHAR(35) NOT NULL DEFAULT ' ',
    min_salary DECIMAL(6,0) DEFAULT 8000,
    max_salary DECIMAL(6,0) DEFAULT NULL
);
