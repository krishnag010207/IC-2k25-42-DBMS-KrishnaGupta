# DBMS Assignment 1

This folder contains the **20 individual SQL solutions** for DBMS Assignment 1.

## Questions

1. [1. Create a simple `countries` table](01_Create_a_simple_countries_table.sql)
2. [2. Create `countries` if it already exists](02_Create_countries_if_it_already_exists.sql)
3. [3. Create the structure of `dup_countries` similar to `countries`](03_Create_the_structure_of_dup_countries_similar_to_countries.sql)
4. [4. Create a duplicate copy of `countries` including structure and data](04_Create_a_duplicate_copy_of_countries_including_structure_and_data.sql)
5. [5. Create `countries` with `NOT NULL` constraints](05_Create_countries_with_NOT_NULL_constraints.sql)
6. [6. Create `jobs` with a maximum salary limit of 25000](06_Create_jobs_with_a_maximum_salary_limit_of_25000.sql)
7. [7. Allow only Italy, India, and China](07_Allow_only_Italy_India_and_China.sql)
8. [8. Create `job_histry` with a date check](08_Create_job_histry_with_a_date_check.sql)
9. [9. Do not allow duplicate `country_id`](09_Do_not_allow_duplicate_country_id.sql)
10. [10. Create `jobs` with default values](10_Create_jobs_with_default_values.sql)
11. [11. Make `country_id` the key field](11_Make_country_id_the_key_field.sql)
12. [12. Make `country_id` unique and auto-incremented](12_Make_country_id_unique_and_auto_incremented.sql)
13. [13. Make the combination of `country_id` and `region_id` unique](13_Make_the_combination_of_country_id_and_region_id_unique.sql)
14. [14. `job_history` with unique employee IDs and a foreign key to `jobs`](14_job_history_with_unique_employee_IDs_and_a_foreign_key_to_jobs.sql)
15. [15. `employees` with a composite foreign key](15_employees_with_a_composite_foreign_key.sql)
16. [16. `employees` with foreign keys to `departments` and `jobs`](16_employees_with_foreign_keys_to_departments_and_jobs.sql)
17. [17. Foreign key with `ON UPDATE CASCADE` and `ON DELETE RESTRICT`](17_Foreign_key_with_ON_UPDATE_CASCADE_and_ON_DELETE_RESTRICT.sql)
18. [18. Foreign key with `ON DELETE CASCADE` and `ON UPDATE RESTRICT`](18_Foreign_key_with_ON_DELETE_CASCADE_and_ON_UPDATE_RESTRICT.sql)
19. [19. Foreign key with `ON DELETE SET NULL` and `ON UPDATE SET NULL`](19_Foreign_key_with_ON_DELETE_SET_NULL_and_ON_UPDATE_SET_NULL.sql)
20. [20. Foreign key with `NO ACTION`](20_Foreign_key_with_NO_ACTION.sql)

## Database

MySQL / HR-style database schema as required by the assignment.

## Submission Structure

Each question is stored as a separate `.sql` file so that it can be uploaded and executed independently.
