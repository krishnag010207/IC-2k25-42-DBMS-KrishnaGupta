-- DBMS Assignment 1
-- Question 19: 19. Foreign key with `ON DELETE SET NULL` and `ON UPDATE SET NULL`

CREATE TABLE IF NOT EXISTS employees (
    employee_id DECIMAL(6,0) NOT NULL PRIMARY KEY,
    first_name VARCHAR(20),
    last_name VARCHAR(25),
    job_id VARCHAR(10) NULL,
    salary DECIMAL(8,2),

    FOREIGN KEY (job_id)
        REFERENCES jobs(job_id)
        ON DELETE SET NULL
        ON UPDATE SET NULL
) ENGINE=InnoDB;
