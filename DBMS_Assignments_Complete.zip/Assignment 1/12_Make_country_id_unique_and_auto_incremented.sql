-- DBMS Assignment 1
-- Question 12: 12. Make `country_id` unique and auto-incremented

CREATE TABLE IF NOT EXISTS countries (
    country_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    country_name VARCHAR(40),
    region_id DECIMAL(10,0)
);
