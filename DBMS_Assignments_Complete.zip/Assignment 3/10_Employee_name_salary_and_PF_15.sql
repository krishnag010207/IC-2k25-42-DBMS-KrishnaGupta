-- DBMS Assignment 3
-- Question 10: 10. Employee name, salary, and PF (15%)

SELECT CONCAT(first_name, ' ', last_name) AS employee_name,
       salary,
       salary * 0.15 AS PF
FROM employees;
