-- DBMS Assignment 3
-- Question 3: 3. Salary not between 10000 and 15000 and department 30 or 100

SELECT first_name,
       last_name,
       salary
FROM employees
WHERE salary NOT BETWEEN 10000 AND 15000
  AND department_id IN (30, 100);
