-- DBMS Assignment 3
-- Question 7: 7. Last names with exactly 6 characters

SELECT last_name
FROM employees
WHERE CHAR_LENGTH(last_name) = 6;
