# DBMS Assignment 3

This folder contains the **11 individual SQL solutions** for DBMS Assignment 3.

## Questions

1. [1. Employees whose salary is not between 10000 and 15000](01_Employees_whose_salary_is_not_between_10000_and_15000.sql)
2. [2. Employees in departments 30 or 100, ordered by department ID](02_Employees_in_departments_30_or_100_ordered_by_department_ID.sql)
3. [3. Salary not between 10000 and 15000 and department 30 or 100](03_Salary_not_between_10000_and_15000_and_department_30_or_100.sql)
4. [4. Employees hired in 1987](04_Employees_hired_in_1987.sql)
5. [5. First names containing both `b` and `c`](05_First_names_containing_both_b_and_c.sql)
6. [6. Programmers or Shipping Clerks excluding specified salaries](06_Programmers_or_Shipping_Clerks_excluding_specified_salaries.sql)
7. [7. Last names with exactly 6 characters](07_Last_names_with_exactly_6_characters.sql)
8. [8. Last names having `e` as the third character](08_Last_names_having_e_as_the_third_character.sql)
9. [9. Jobs/designations available in employees](09_Jobs_designations_available_in_employees.sql)
10. [10. Employee name, salary, and PF (15%)](10_Employee_name_salary_and_PF_15.sql)
11. [11. Employees whose last name is BLAKE, SCOTT, KING, or FORD](11_Employees_whose_last_name_is_BLAKE_SCOTT_KING_or_FORD.sql)

## Database

MySQL / HR-style database schema as required by the assignment.

## Submission Structure

Each question is stored as a separate `.sql` file so that it can be uploaded and executed independently.
