-- DBMS Assignment 3
-- Question 5: 5. First names containing both `b` and `c`

SELECT first_name
FROM employees
WHERE LOWER(first_name) LIKE '%b%'
  AND LOWER(first_name) LIKE '%c%';
