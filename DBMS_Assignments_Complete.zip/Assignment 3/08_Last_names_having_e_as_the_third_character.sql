-- DBMS Assignment 3
-- Question 8: 8. Last names having `e` as the third character

SELECT last_name
FROM employees
WHERE LOWER(last_name) LIKE '__e%';
