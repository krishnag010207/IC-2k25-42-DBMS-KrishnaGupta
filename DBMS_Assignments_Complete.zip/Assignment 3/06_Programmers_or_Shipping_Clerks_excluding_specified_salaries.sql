-- DBMS Assignment 3
-- Question 6: 6. Programmers or Shipping Clerks excluding specified salaries

SELECT last_name,
       job_id,
       salary
FROM employees
WHERE job_id IN ('IT_PROG', 'SH_CLERK')
  AND salary NOT IN (4500, 10000, 15000);
