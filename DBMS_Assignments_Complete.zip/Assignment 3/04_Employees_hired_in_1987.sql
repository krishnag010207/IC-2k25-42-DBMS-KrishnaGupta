-- DBMS Assignment 3
-- Question 4: 4. Employees hired in 1987

SELECT first_name,
       last_name,
       hire_date
FROM employees
WHERE YEAR(hire_date) = 1987;
