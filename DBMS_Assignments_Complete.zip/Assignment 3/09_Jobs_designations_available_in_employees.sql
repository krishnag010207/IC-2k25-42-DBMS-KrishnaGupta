-- DBMS Assignment 3
-- Question 9: 9. Jobs/designations available in employees

SELECT DISTINCT job_id
FROM employees;
