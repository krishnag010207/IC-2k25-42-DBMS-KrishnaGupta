-- DBMS Assignment 3
-- Question 11: 11. Employees whose last name is BLAKE, SCOTT, KING, or FORD

SELECT *
FROM employees
WHERE UPPER(last_name) IN ('BLAKE', 'SCOTT', 'KING', 'FORD');
