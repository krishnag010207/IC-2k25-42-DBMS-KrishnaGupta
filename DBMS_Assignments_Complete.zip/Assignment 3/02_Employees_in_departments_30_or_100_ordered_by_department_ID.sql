-- DBMS Assignment 3
-- Question 2: 2. Employees in departments 30 or 100, ordered by department ID

SELECT first_name,
       last_name,
       department_id
FROM employees
WHERE department_id IN (30, 100)
ORDER BY department_id ASC;
